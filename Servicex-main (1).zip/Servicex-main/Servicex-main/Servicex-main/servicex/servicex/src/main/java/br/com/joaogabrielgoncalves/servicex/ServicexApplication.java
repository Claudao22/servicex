package br.com.joaogabrielgoncalves.servicex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicexApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicexApplication.class, args);
	}

}
